## Assignment \#2 - Connect Professional Dots!

---

### Overview

This assignment is designed to dip your toe in the networking water, and talk to others in the technology field! Although we recommend that you complete this mission, it is not a requirement for completing the pre-work or course. It could however be very beneficial to you. Networking is one of the best ways to find your next opportunity!

### Instructions

1. Read through the "[Time to get employable](module-3-time-to-get-employable.md)" chapter of Pre-Work.

2. Browse [Eventbrite](https://www.eventbrite.com/) and/or [Meetup](http://meetup.com/) for an event that occurs **before the boot camp starts** that sparks your interest!

3. Attend the event, alone or with friends and talk to at least two people **you did not know previous to the event**.

### Note

* No trick assignment here. We want you to meet people, have fun and reflect.
