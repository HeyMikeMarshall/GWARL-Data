# Module \#5 Let's Get To Work \(Assignment Required\)

## So You Wanna Be A Data Analyst...

Well, you've come to the right place! Over the course of the next six months, you will be working on developing the necessary skills to become a Data Analytics Pro.

### Instructions:

1. In Google Drive, create a file titled "Data Analytics and I".
      \* If you haven't created a Google Drive account, please go back to Module \# 2 and complete the steps.

2. Write 200 words about what you want to learn in this class and what you are most excited to learn.

3. Write 100 words about what these skills will do for your career! If you don't have a career in this field yet- no problem! Write about how these skills will help you reach your goal.

4. **Once you complete this assignment, copy the Google document link into BootcampSpot!**
